<?php
$action="baocao";
switch($action)
{
    case "baocao":
        include 'View/baocao.php';
        break;
}
?>
