<?php
$action="thongke";
switch($action)
{
    case "thongke":
        include "View/thongke.php";
        break;
}
?>