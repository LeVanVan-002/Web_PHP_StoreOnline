<div class="container">
      <div class="row text-center">
          <div class="col-12">
        
              <img src="Content/image2/ship.gif" height="200px" alt="" />
          </div>
      </div>
  </div>