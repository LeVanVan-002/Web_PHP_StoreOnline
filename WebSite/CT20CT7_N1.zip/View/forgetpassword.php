<section class="login-block">
  <div class="container">
    <div class="row">
      <div class="col-md-4 login-sec">
        <!-- <h3 class="text-center"><b>Login Now</b></h3> -->
        <form  action="index.php?action=forgetps&act=forgetps_action" class="login-form" method="post">
          <div class="form-group">
            <label for="exampleInputEmail1" class="text-uppercase">Nhập địa chỉ email để gửi liên kết mật khẩu</label>
            <input type="text" class="form-control" name="email" placeholder="">
          </div>
          <div class="form-check">
            <!-- người dùng nhanas nút submit -->
            <input type="submit" name="submit_email">
          </div>
        </form>
        <div class="copy-text">Shop caffe <i class="fa fa-heart"></i><a href="">CD20CT7_N1.com</a></div>
      </div>
      </div>
    </div>
</section>