<div class="login-box">
  <h2>Thay Đôii Mật Khẩu Của Bạn  </h2>
  <form action="index.php?action=thaydoimk&act=thaydoimk_action" class="login-form" method="post">
    <div class="user-box">
      <input type="password" class="form-control" name="txtpassword_cu"  placeholder="nhập mật khẩu cũ ">
      <label  for="exampleInputEmail1" class="text-uppercase" >Mật Khẩu Cũ</label>
    </div>
    <div class="user-box">
      <input type="password" class="form-control" name="txtpassword_moi"  placeholder="nhập nhập mật khẩu mới  ">
      <label for="exampleInputPassword1" class="text-uppercase" >Mật Khẩu Mới </label>
    </div>
    <div class="user-box">
      <input type="password" class="form-control"  name="txtpassword_moi" placeholder="nhập lại nhập mật khẩu mới  ">
      <label for="exampleInputPassword1" class="text-uppercase" >Nhập Lại Mật Khẩu Mới  </label>
    </div>
    <a href="#">
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <button class="btn btn-primary float-right" type="submit"> Cập Nhật </button> </a>
  </form>
</div>
<link rel="stylesheet" href="./Content/CSS/login.css">